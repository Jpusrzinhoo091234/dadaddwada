const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ApplicationCommandType, ApplicationCommandOptionType } = require("discord.js")
const { perms, General, emoji } = require("../../DataBaseJson")

module.exports = {
   name: "botconfig",
   description: "[🛠️|💰 Vendas Moderação] Configure o bot",
   run: async(client, interaction) => {
       if (!perms.has(interaction.user.id)) return interaction.reply({
         embeds: [new EmbedBuilder()
           .setDescription(`${emoji.get(`alerta`)} | Você não possui permissão para utilizar este comando!`)
           .setColor("Red")
         ],
         ephemeral: true 
       })
       
       const embed = new EmbedBuilder()
        .setAuthor({ name: interaction.client.user.username, iconURL: interaction.client.user.displayAvatarURL()})
        .setDescription(`${emoji.get(`configbot`)} | **Painel de Configuração do bot**\n\n<:Pussy_verificadd:1258087335501762570> | Sistema de Vendas: ${General.get(`vendas`)}\n\n[Blank](https://discord.gg/exemplo)`)
        .setColor(General.get(`color.padrao`))
        .setThumbnail(interaction.client.user.displayAvatarURL())
        
       const row = new ActionRowBuilder()
        .addComponents(
           new ButtonBuilder()
            .setCustomId(`${interaction.user.id}_vendasonoff`)
            .setLabel('Vendas On/Off')
            .setEmoji(`<a:onoff:1258076650650861661>`)
            .setStyle(General.get(`vendas`) == "ON" ? 3 : 4),
           new ButtonBuilder()
            .setCustomId(`${interaction.user.id}_configpayment`)
            .setLabel('Configurar Pagamento')
            .setEmoji(`1157338170757746729`)
            .setStyle(1),
           new ButtonBuilder()
            .setCustomId(`${interaction.user.id}_configbot`)
            .setLabel('Configurar Bot')
            .setEmoji(`<:robo:1258088520497758228>`)
            .setStyle(1),
           new ButtonBuilder()
            .setCustomId(`${interaction.user.id}_configcanais`)
            .setLabel('Configurar Canais')
            .setEmoji(`<:Pussy_kit:1258088730959548429>`)
            .setStyle(1),
           new ButtonBuilder()
            .setCustomId(`${interaction.user.id}_configtermos`)
            .setLabel('Configurar os Termos de compra')
            .setEmoji(`1184105676545474631`)
            .setStyle(1)
        )
        
        const row2 = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
           .setCustomId(`${interaction.user.id}_blacklist`)
           .setLabel('Personalizar BlackList')
           .setEmoji(`<:Pussy_membroban:1258081308307882024>`)
           .setStyle(2)
        )
        
       interaction.reply({ embeds: [embed], components: [row, row2] })
       
       setTimeout(() => {
          interaction.editReply({ content: `${emoji.get(`alerta`)} | Utilize o Comando Novamente!`, embeds: [], components: [] }).catch(error => {return})
       }, 300000)
   }
}